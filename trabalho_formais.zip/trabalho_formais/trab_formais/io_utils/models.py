from django.db import models


# Create your models here.
class FiniteAutomata(models.Model):
    content = models.TextField()
