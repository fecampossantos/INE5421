from django.apps import AppConfig


class IoUtilsConfig(AppConfig):
    #name = 'ine5421'
    name = 'io_utils'
